public interface Post {

    // j'ai pas modifié l'interface, j'ai préféré créé une classe Abstraite à coté nommé PostAbs

    public User getAuthor();
    public void display();
}
