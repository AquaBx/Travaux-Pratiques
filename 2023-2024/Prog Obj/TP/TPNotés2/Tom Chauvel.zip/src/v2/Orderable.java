package v2;

public interface Orderable {
    public String getName();
    public double getCost();
}
