package v1;

public interface Orderable {
    public String getName();
    public double getCost();
}
