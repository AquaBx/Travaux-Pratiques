﻿#include "OrRule.h"
