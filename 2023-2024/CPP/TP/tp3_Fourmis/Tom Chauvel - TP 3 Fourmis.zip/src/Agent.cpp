#include "Agent.h"
#include <set>

std::set<Agent*> Agent::mesAgents = {};
