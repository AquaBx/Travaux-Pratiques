﻿#include "AbstractRule.h"
