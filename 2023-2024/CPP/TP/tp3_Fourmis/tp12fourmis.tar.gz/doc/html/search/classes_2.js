var searchData=
[
  ['localizedentity',['LocalizedEntity',['../class_environment_1_1_localized_entity.html',1,'Environment']]]
];
