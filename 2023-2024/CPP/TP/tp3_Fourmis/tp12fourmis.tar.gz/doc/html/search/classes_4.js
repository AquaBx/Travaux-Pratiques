var searchData=
[
  ['string',['String',['../struct_renderer_1_1_string.html',1,'Renderer']]]
];
