var searchData=
[
  ['setposition',['setPosition',['../class_environment_1_1_localized_entity.html#a402f1a18bec26f13df294502c8b47930',1,'Environment::LocalizedEntity']]],
  ['setradius',['setRadius',['../class_environment_1_1_localized_entity.html#a0708ebfc802bf5248e68466c8be9086f',1,'Environment::LocalizedEntity']]]
];
