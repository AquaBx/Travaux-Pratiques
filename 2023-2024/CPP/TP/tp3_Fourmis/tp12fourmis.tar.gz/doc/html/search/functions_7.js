var searchData=
[
  ['localizedentity',['LocalizedEntity',['../class_environment_1_1_localized_entity.html#ae12f75cffb61b3f9b6993eff2e4f61b1',1,'Environment::LocalizedEntity']]]
];
