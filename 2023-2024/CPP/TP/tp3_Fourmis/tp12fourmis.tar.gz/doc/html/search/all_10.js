var searchData=
[
  ['vector2',['Vector2',['../class_vector2.html',1,'Vector2&lt; Scalar &gt;'],['../class_vector2.html#a3d1acc04bc01f9ecc51217cce9897f5b',1,'Vector2::Vector2()']]],
  ['vector2_3c_20float_20_3e',['Vector2&lt; float &gt;',['../class_vector2.html',1,'']]]
];
