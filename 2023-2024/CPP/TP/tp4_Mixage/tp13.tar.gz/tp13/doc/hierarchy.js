var hierarchy =
[
    [ "composant", "classcomposant.xhtml", [
      [ "consommateur", "classconsommateur.xhtml", [
        [ "enregistreur_fichier", "classenregistreur__fichier.xhtml", null ],
        [ "enregistreur_fichier_texte", "classenregistreur__fichier__texte.xhtml", null ],
        [ "filtre", "classfiltre.xhtml", null ]
      ] ],
      [ "producteur", "classproducteur.xhtml", [
        [ "filtre", "classfiltre.xhtml", null ]
      ] ]
    ] ],
    [ "std::exception", null, [
      [ "composant_exception", "classcomposant__exception.xhtml", null ]
    ] ],
    [ "flot", "classflot.xhtml", null ]
];